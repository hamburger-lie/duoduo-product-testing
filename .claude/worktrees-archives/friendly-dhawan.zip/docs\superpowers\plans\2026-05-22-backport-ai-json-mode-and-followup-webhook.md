# Backport feat/01-ai-json-mode + feat/02-followup-webhook to Local Backend

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Manually apply the diff from `duoduo/feat/01-ai-json-mode` and `duoduo/feat/02-followup-webhook` into the local backend at `D:\soul\backend\`, which has significantly diverged from `duoduo/main`.

**Architecture:** Since the local backend (`D:\soul\backend\`) has ~80+ locally-modified files and multiple new migrations beyond what `duoduo/main` has, a `git cherry-pick` or `git merge` would cause massive conflicts. Instead we apply the specific diff hunks to each target file manually, then run tests to verify.

**Tech Stack:** Python 3.12, FastAPI, SQLAlchemy async, Alembic, Celery, httpx, DeepSeek/Ark AI API

---

## Key Decisions

1. **No git cherry-pick**: Local backend has diverged from `duoduo/main`. Manual patch is safer.
2. **Migration `down_revision`**: The webhook migration in the branch uses `down_revision = "20260519_0002"`. Local latest migration is `20260519_0004`. We adjust to `down_revision = "20260519_0004"`.
3. **`_complete()` json_mode flow**: Local `_complete()` has `max_tokens` support and extra retry logic (httpx.TimeoutException). We add `json_mode` param + pass to `_stream_collect`, and also catch `AIServiceUnavailable` for retry (empty-response retry).
4. **`_complete_json()` json_mode**: Local version calls `self._complete()`, so we pass `json_mode=True` there (not directly to `_stream_collect`).
5. **test_evaluation_tasks.py**: Local file is untracked/modified. We append only the new webhook test case.
6. **Skip**: `.github/workflows/`, root-level `API_CONTRACT.md` and `docs/API_STATUS.md` from duoduo — these are duoduo-repo docs, not the local backend's docs.

---

## File Map

### feat/01-ai-json-mode
- Modify: `D:\soul\backend\backend\app\ai\client.py`

### feat/02-followup-webhook
- Modify: `D:\soul\backend\backend\app\core\config.py`
- Modify: `D:\soul\backend\backend\.env.example`
- Create: `D:\soul\backend\backend\app\db\models\webhook_event.py`
- Modify: `D:\soul\backend\backend\app\db\models\__init__.py`
- Create: `D:\soul\backend\backend\app\db\repositories\webhook_event.py`
- Create: `D:\soul\backend\backend\app\services\followup_webhook_service.py`
- Create: `D:\soul\backend\backend\app\tasks\followup_webhook_tasks.py`
- Modify: `D:\soul\backend\backend\app\tasks\celery_app.py`
- Modify: `D:\soul\backend\backend\app\tasks\evaluation_tasks.py`
- Create: `D:\soul\backend\backend\alembic\versions\20260521_0001_add_webhook_events.py`
- Create: `D:\soul\backend\backend\tests\test_followup_webhook.py`
- Modify: `D:\soul\backend\backend\tests\test_evaluation_tasks.py`

---

## Task 1: feat/01-ai-json-mode — Add json_mode + reasoning_content fallback to client.py

**Files:**
- Modify: `D:\soul\backend\backend\app\ai\client.py`

### Changes to apply

- [ ] **Step 1: Add `json_mode` param and `reasoning_content` fallback to `_stream_collect()`**

Find the `_stream_collect` method (starts at line 212). Make these changes:

1a. Add `json_mode: bool = False` parameter after `max_tokens`:
```python
    async def _stream_collect(
        self,
        *,
        system: str,
        user: str,
        endpoint_id: str,
        images: list[str] | None = None,
        max_tokens: int | None = None,
        json_mode: bool = False,
    ) -> str:
```

1b. After `if max_tokens is not None: payload["max_tokens"] = max_tokens` (around line 237), add:
```python
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
```

1c. After `collected: list[str] = []` (line 239), add:
```python
        reasoning_collected: list[str] = []
```

1d. After the `if content: collected.append(str(content))` block (around line 272), add:
```python
                        reasoning = delta.get("reasoning_content", "")
                        if reasoning:
                            reasoning_collected.append(str(reasoning))
```

1e. Replace `return "".join(collected)` (line 276) with:
```python
        result = "".join(collected)
        if not result.strip() and reasoning_collected:
            logger.warning(
                "ark_content_in_reasoning endpoint=%s reasoning_len=%d",
                endpoint_id,
                sum(len(c) for c in reasoning_collected),
            )
            result = "".join(reasoning_collected)
        if not result.strip():
            logger.warning(
                "ark_empty_response endpoint=%s", endpoint_id,
            )
            raise AIServiceUnavailable(
                "Ark API returned empty response"
            )
        return result
```

- [ ] **Step 2: Add `json_mode` param to `_complete()` and catch `AIServiceUnavailable` for retry**

Find the `_complete` method (around line 322). Make these changes:

2a. Add `json_mode: bool = False` parameter after `max_tokens`:
```python
    async def _complete(
        self,
        *,
        system: str,
        user: str,
        endpoint_id: str,
        images: list[str] | None = None,
        max_tokens: int | None = None,
        json_mode: bool = False,
    ) -> str:
```

2b. Pass `json_mode` to `_stream_collect`:
```python
                return await self._stream_collect(
                    system=system, user=user, endpoint_id=endpoint_id,
                    images=images, max_tokens=max_tokens, json_mode=json_mode,
                )
```

2c. Expand the `except AIRateLimited` clause to also catch `AIServiceUnavailable` (for empty-response retry):
```python
            except (AIRateLimited, AIServiceUnavailable) as exc:
                last_exc = exc
                if attempt < max_attempts - 1:
                    wait = 5.0 * (attempt + 1)
                    logger.warning(
                        "ark_transient_retry attempt=%d wait=%.1fs error=%s",
                        attempt + 1,
                        wait,
                        type(exc).__name__,
                    )
                    await asyncio.sleep(wait)
                    continue
                raise
```

- [ ] **Step 3: Pass `json_mode=True` from `_complete_json()` to `_complete()`**

Find `_complete_json` (around line 419). The call to `self._complete(...)` (around line 453) should add `json_mode=True`:
```python
            text = await self._complete(
                system=retry_system,
                user=user,
                endpoint_id=endpoint_id,
                images=images,
                max_tokens=max_tokens,
                json_mode=True,
            )
```

- [ ] **Step 4: Add `reasoning_content` fallback to the streaming `_stream()` generator**

Find in `_stream()` (around line 556-558):
```python
                                content = delta.get("content", "")
                                if content:
                                    yield str(content)
```

Replace with:
```python
                                content = delta.get("content", "")
                                if not content:
                                    content = delta.get("reasoning_content", "")
                                if content:
                                    yield str(content)
```

- [ ] **Step 5: Verify `AIServiceUnavailable` is imported at top of client.py**

Run:
```bash
grep -n "AIServiceUnavailable" D:/soul/backend/backend/app/ai/client.py | head -5
```
Expected: it's already imported (it's used elsewhere). If not, add to the exceptions import.

- [ ] **Step 6: Commit**

```bash
cd D:/soul/backend
git add backend/app/ai/client.py
git commit -m "feat: add json_mode to _stream_collect + reasoning_content fallback (backport feat/01-ai-json-mode)"
```

---

## Task 2: feat/02-followup-webhook — Config + env vars

**Files:**
- Modify: `D:\soul\backend\backend\app\core\config.py`
- Modify: `D:\soul\backend\backend\.env.example`

- [ ] **Step 1: Add 3 webhook settings to `config.py`**

Find `evaluation_run_mode` field (around line 39). After that line, add:
```python
    followup_webhook_url: str = Field(default="", alias="FOLLOWUP_WEBHOOK_URL")
    followup_webhook_secret: str = Field(default="", alias="FOLLOWUP_WEBHOOK_SECRET")
    followup_webhook_timeout_seconds: float = Field(
        default=5.0,
        alias="FOLLOWUP_WEBHOOK_TIMEOUT_SECONDS",
    )
```

- [ ] **Step 2: Add secret-length validation to `config.py`**

Find the `model_validator` or `@validator` block (around line 144). After the `evaluation_run_mode` validation block, add:
```python
        if self.followup_webhook_url and len(self.followup_webhook_secret) < 32:
            raise ValueError(
                "FOLLOWUP_WEBHOOK_SECRET must be at least 32 characters when "
                "FOLLOWUP_WEBHOOK_URL is set in production"
            )
```

- [ ] **Step 3: Add env vars to `.env.example`**

Open `D:\soul\backend\backend\.env.example`. After `EVALUATION_RUN_MODE=sync`, add:
```
FOLLOWUP_WEBHOOK_URL=
FOLLOWUP_WEBHOOK_SECRET=
FOLLOWUP_WEBHOOK_TIMEOUT_SECONDS=5
```

- [ ] **Step 4: Commit**

```bash
cd D:/soul/backend
git add backend/app/core/config.py backend/.env.example
git commit -m "feat: add followup webhook config settings (backport feat/02-followup-webhook)"
```

---

## Task 3: feat/02-followup-webhook — Database model + repository

**Files:**
- Create: `D:\soul\backend\backend\app\db\models\webhook_event.py`
- Modify: `D:\soul\backend\backend\app\db\models\__init__.py`
- Create: `D:\soul\backend\backend\app\db\repositories\webhook_event.py`

- [ ] **Step 1: Create `webhook_event.py` model**

Create `D:\soul\backend\backend\app\db\models\webhook_event.py`:
```python
from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import JSONB_TYPE, Base, BaseModelMixin, JsonDict


class WebhookEvent(Base, BaseModelMixin):
    """Durable outbound webhook event."""

    __tablename__ = "webhook_events"
    __table_args__ = (
        Index("ix_webhook_events_status_next_attempt", "status", "next_attempt_at"),
        Index("ix_webhook_events_event_id", "event_id", unique=True),
    )

    event_id: Mapped[str] = mapped_column(String(128), nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    target_url: Mapped[str] = mapped_column(String(1024), nullable=False)
    payload: Mapped[JsonDict] = mapped_column(JSONB_TYPE, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="pending")
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
```

- [ ] **Step 2: Verify `JSONB_TYPE`, `Base`, `BaseModelMixin`, `JsonDict` are exported from `app.db.base`**

```bash
grep -n "JSONB_TYPE\|BaseModelMixin\|JsonDict" D:/soul/backend/backend/app/db/base.py | head -10
```
Expected: all four names present. If any are missing, check the actual names in `base.py` and adjust.

- [ ] **Step 3: Add `WebhookEvent` to `models/__init__.py`**

Open `D:\soul\backend\backend\app\db\models\__init__.py`. Add import after the last existing model import:
```python
from app.db.models.webhook_event import WebhookEvent
```

And add `WebhookEvent` to the tuple returned by `load_all_models()`.

- [ ] **Step 4: Create `webhook_event.py` repository**

Create `D:\soul\backend\backend\app\db\repositories\webhook_event.py`:
```python
from __future__ import annotations

from datetime import datetime
from typing import cast

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models.webhook_event import WebhookEvent
from app.db.repositories.base import BaseRepository


class WebhookEventRepository(BaseRepository[WebhookEvent]):
    """Repository for outbound webhook events."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(session=session, model=WebhookEvent)

    async def get_by_event_id(self, *, event_id: str) -> WebhookEvent | None:
        """Return one webhook event by idempotency event ID."""

        return cast(
            WebhookEvent | None,
            await self.session.scalar(
                select(WebhookEvent).where(
                    WebhookEvent.event_id == event_id,
                    WebhookEvent.deleted_at.is_(None),
                )
            ),
        )

    async def list_ready_for_delivery(
        self,
        *,
        now: datetime,
        limit: int = 100,
    ) -> list[WebhookEvent]:
        """Return pending/failed events whose retry time has arrived."""

        result = await self.session.scalars(
            select(WebhookEvent)
            .where(
                WebhookEvent.deleted_at.is_(None),
                WebhookEvent.status.in_(("pending", "failed")),
                (
                    (WebhookEvent.next_attempt_at.is_(None))
                    | (WebhookEvent.next_attempt_at <= now)
                ),
            )
            .order_by(WebhookEvent.created_at.asc(), WebhookEvent.id.asc())
            .limit(limit)
        )
        return list(result.all())
```

- [ ] **Step 5: Verify `BaseRepository` constructor signature**

```bash
grep -n "class BaseRepository\|def __init__" D:/soul/backend/backend/app/db/repositories/base.py | head -10
```
Expected: `__init__` accepts `session` and `model` kwargs. Adjust the repository if the local signature differs.

- [ ] **Step 6: Commit**

```bash
cd D:/soul/backend
git add backend/app/db/models/webhook_event.py backend/app/db/models/__init__.py backend/app/db/repositories/webhook_event.py
git commit -m "feat: add WebhookEvent model and repository (backport feat/02-followup-webhook)"
```

---

## Task 4: feat/02-followup-webhook — Service layer

**Files:**
- Create: `D:\soul\backend\backend\app\services\followup_webhook_service.py`

- [ ] **Step 1: Create `followup_webhook_service.py`**

Create `D:\soul\backend\backend\app\services\followup_webhook_service.py`:
```python
from __future__ import annotations

import hashlib
import hmac
from collections import Counter
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.db.models.answer import Answer
from app.db.models.evaluation import Evaluation
from app.db.models.product import Product
from app.db.models.user import User
from app.db.models.webhook_event import WebhookEvent
from app.db.repositories.evaluation import EvaluationRepository
from app.db.repositories.webhook_event import WebhookEventRepository


def sign_webhook_body(*, secret: str, body: bytes) -> str:
    """Return the HMAC-SHA256 signature for a webhook body."""

    digest = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


class FollowupWebhookService:
    """Create outbound follow-up webhook events from evaluation results."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.evaluations = EvaluationRepository(session)
        self.events = WebhookEventRepository(session)

    async def create_event_for_evaluation(
        self,
        *,
        evaluation_id: int,
    ) -> WebhookEvent | None:
        """Create or return a durable event for a terminal evaluation."""

        settings = get_settings()
        target_url = settings.followup_webhook_url.strip()
        if not target_url:
            return None

        evaluation = await self.evaluations.get_by_id(evaluation_id)
        if evaluation is None or evaluation.status not in {"done", "failed"}:
            return None

        event_type = f"evaluation.{evaluation.status}"
        event_id = f"{event_type}:{evaluation.id}"
        existing = await self.events.get_by_event_id(event_id=event_id)
        if existing is not None:
            return existing

        answers = await self._list_answers(evaluation_id=evaluation.id)
        user = await self.session.get(User, evaluation.user_id)
        product = await self.session.get(Product, evaluation.product_id)
        payload = self.build_payload(
            evaluation=evaluation,
            event_id=event_id,
            event_type=event_type,
            answers=answers,
            user=user,
            product=product,
        )
        return await self.events.create(
            {
                "event_id": event_id,
                "event_type": event_type,
                "target_url": target_url,
                "payload": payload,
                "status": "pending",
                "attempt_count": 0,
            }
        )

    def build_payload(
        self,
        *,
        evaluation: Evaluation,
        event_id: str,
        event_type: str,
        answers: list[Answer],
        user: User | None,
        product: Product | None,
    ) -> dict[str, object]:
        """Build the follow-up payload for the configured external receiver."""

        completed = [answer for answer in answers if answer.status == "done"]
        failed = [answer for answer in answers if answer.status == "failed"]
        intents = [
            int(answer.overall_intent)
            for answer in completed
            if answer.overall_intent is not None
        ]
        sentiment_counts = Counter(answer.sentiment for answer in completed if answer.sentiment)
        overall_sentiment = (
            sentiment_counts.most_common(1)[0][0] if sentiment_counts else "neutral"
        )
        average_intent = round(sum(intents) / len(intents), 2) if intents else None

        return {
            "event": event_type,
            "event_id": event_id,
            "occurred_at": self._format_dt(datetime.now(UTC)),
            "user_id": str(evaluation.user_id),
            "evaluation_id": str(evaluation.id),
            "product_id": str(evaluation.product_id),
            "status": evaluation.status,
            "user": {
                "id": str(evaluation.user_id),
                "openid": user.openid if user else None,
                "nickname": user.nickname if user else None,
            },
            "product": {
                "id": str(evaluation.product_id),
                "image_keys": self._image_keys(product),
            },
            "summary": {
                "total_personas": len(evaluation.selected_persona_ids),
                "completed_personas": len(completed),
                "failed_personas": len(failed),
                "average_intent": average_intent,
                "overall_sentiment": overall_sentiment,
            },
            "answers": [self._answer_payload(answer) for answer in answers],
        }

    async def _list_answers(self, *, evaluation_id: int) -> list[Answer]:
        result = await self.session.scalars(
            select(Answer).where(
                Answer.evaluation_id == evaluation_id,
                Answer.deleted_at.is_(None),
            )
        )
        return list(result.all())

    def _format_dt(self, value: datetime) -> str:
        return value.astimezone(UTC).isoformat().replace("+00:00", "Z")

    def _image_keys(self, product: Product | None) -> list[str]:
        if product is None:
            return []
        return [str(value) for value in product.image_urls]

    def _answer_payload(self, answer: Answer) -> dict[str, object]:
        return {
            "persona_id": str(answer.persona_id),
            "status": answer.status,
            "answers": answer.answers,
            "overall_intent": answer.overall_intent,
            "sentiment": answer.sentiment,
            "summary_comment": answer.summary_comment,
            "thinking_process": answer.thinking_process,
            "token_input": answer.token_input,
            "token_output": answer.token_output,
            "cost_yuan": str(answer.cost_yuan) if answer.cost_yuan is not None else None,
            "error_message": answer.error_message,
        }
```

- [ ] **Step 2: Verify `EvaluationRepository.get_by_id` exists**

```bash
grep -n "def get_by_id" D:/soul/backend/backend/app/db/repositories/evaluation.py | head -5
```
Expected: method exists. If named differently, update the import/call in `followup_webhook_service.py`.

- [ ] **Step 3: Verify `Answer` model has all referenced fields**

```bash
grep -n "overall_intent\|sentiment\|summary_comment\|thinking_process\|token_input\|token_output\|cost_yuan\|error_message" D:/soul/backend/backend/app/db/models/answer.py | head -15
```
Expected: all fields present.

- [ ] **Step 4: Commit**

```bash
cd D:/soul/backend
git add backend/app/services/followup_webhook_service.py
git commit -m "feat: add FollowupWebhookService for outbound evaluation webhooks (backport feat/02-followup-webhook)"
```

---

## Task 5: feat/02-followup-webhook — Task layer (Celery)

**Files:**
- Create: `D:\soul\backend\backend\app\tasks\followup_webhook_tasks.py`
- Modify: `D:\soul\backend\backend\app\tasks\celery_app.py`
- Modify: `D:\soul\backend\backend\app\tasks\evaluation_tasks.py`

- [ ] **Step 1: Create `followup_webhook_tasks.py`**

Create `D:\soul\backend\backend\app\tasks\followup_webhook_tasks.py`:
```python
from __future__ import annotations

import asyncio
import json
import logging
from datetime import UTC, datetime, timedelta

import httpx

from app.core.config import get_settings
from app.services.followup_webhook_service import sign_webhook_body
from app.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)


def _run_async(coro: object) -> dict[str, object]:
    loop = asyncio.new_event_loop()
    try:
        result: dict[str, object] = loop.run_until_complete(coro)  # type: ignore[arg-type]
        return result
    finally:
        loop.close()


@celery_app.task(  # type: ignore[untyped-decorator]
    name="followup_webhook.deliver",
    bind=True,
    max_retries=0,
)
def deliver_followup_webhook_event_task(self: object, event_id: int) -> dict[str, object]:
    """Celery wrapper for delivering one follow-up webhook event."""

    return _run_async(deliver_followup_webhook_event(event_id))


async def deliver_followup_webhook_event(event_id: int) -> dict[str, object]:
    """Deliver one webhook event and persist delivery status."""

    from app.db.models.webhook_event import WebhookEvent
    from app.db.session import AsyncSessionFactory

    settings = get_settings()
    async with AsyncSessionFactory() as session:
        event = await session.get(WebhookEvent, event_id)
        if event is None:
            return {"status": "missing", "event_id": str(event_id)}
        if event.status == "delivered":
            return {"status": "delivered", "event_id": str(event_id)}

        body = json.dumps(
            event.payload,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "X-Webhook-Event-Id": event.event_id,
            "X-Webhook-Signature": sign_webhook_body(
                secret=settings.followup_webhook_secret,
                body=body,
            ),
        }

        event.attempt_count += 1
        try:
            timeout = httpx.Timeout(settings.followup_webhook_timeout_seconds)
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.post(
                    event.target_url,
                    content=body,
                    headers=headers,
                )
            if 200 <= response.status_code < 300:
                event.status = "delivered"
                event.delivered_at = datetime.now(UTC)
                event.last_error = None
                event.next_attempt_at = None
                await session.commit()
                return {"status": "delivered", "event_id": str(event.id)}

            event.status = "failed"
            event.last_error = f"HTTP {response.status_code}: {response.text[:200]}"
            event.next_attempt_at = _next_attempt_at(event.attempt_count)
            await session.commit()
            return {"status": "failed", "event_id": str(event.id)}
        except httpx.HTTPError as exc:
            event.status = "failed"
            event.last_error = str(exc)[:200]
            event.next_attempt_at = _next_attempt_at(event.attempt_count)
            await session.commit()
            logger.warning(
                "followup_webhook_delivery_failed",
                extra={
                    "event": "followup_webhook_delivery_failed",
                    "webhook_event_id": event.id,
                    "attempt_count": event.attempt_count,
                },
            )
            return {"status": "failed", "event_id": str(event.id)}


def _next_attempt_at(attempt_count: int) -> datetime:
    delay_seconds = min(3600, 2 ** max(0, attempt_count - 1) * 60)
    return datetime.now(UTC) + timedelta(seconds=delay_seconds)
```

- [ ] **Step 2: Add `followup_webhook_tasks` to celery imports**

In `D:\soul\backend\backend\app\tasks\celery_app.py`, find:
```python
        imports=("app.tasks.evaluation_tasks", "app.tasks.watchdog"),
```
Replace with:
```python
        imports=(
            "app.tasks.evaluation_tasks",
            "app.tasks.followup_webhook_tasks",
            "app.tasks.watchdog",
        ),
```

- [ ] **Step 3: Add webhook hook calls to `evaluation_tasks.py`**

In `D:\soul\backend\backend\app\tasks\evaluation_tasks.py`:

3a. After the `logger.info("evaluation_finalized", ...)` block (around line 387), before `return {`, add:
```python
            await _create_followup_webhook_event(evaluation_id=evaluation_id)
```

3b. After `await session.commit()` in the `except Exception` handler (around line 421), add:
```python
                await _create_followup_webhook_event(evaluation_id=evaluation_id)
```

3c. At the end of the file (after the `_finalize_evaluation` function), append:
```python


async def _create_followup_webhook_event(*, evaluation_id: int) -> None:
    """Persist and enqueue an outbound follow-up webhook event if enabled."""

    from app.db.session import AsyncSessionFactory
    from app.services.followup_webhook_service import FollowupWebhookService
    from app.tasks.followup_webhook_tasks import deliver_followup_webhook_event_task

    async with AsyncSessionFactory() as session:
        event = await FollowupWebhookService(session).create_event_for_evaluation(
            evaluation_id=evaluation_id,
        )
        if event is None:
            return
        await session.commit()
        event_id = event.id

    try:
        deliver_followup_webhook_event_task.apply_async(
            args=[event_id],
            queue="webhooks",
        )
    except Exception as exc:
        logger.warning(
            "followup_webhook_enqueue_failed",
            extra={
                "event": "followup_webhook_enqueue_failed",
                "evaluation_id": evaluation_id,
                "webhook_event_id": event_id,
                "error_message": str(exc)[:200],
            },
        )
```

- [ ] **Step 4: Commit**

```bash
cd D:/soul/backend
git add backend/app/tasks/followup_webhook_tasks.py backend/app/tasks/celery_app.py backend/app/tasks/evaluation_tasks.py
git commit -m "feat: add Celery webhook delivery task + hook into evaluation_tasks (backport feat/02-followup-webhook)"
```

---

## Task 6: feat/02-followup-webhook — Alembic migration

**Files:**
- Create: `D:\soul\backend\backend\alembic\versions\20260521_0001_add_webhook_events.py`

- [ ] **Step 1: Create migration (with adjusted `down_revision`)**

Note: Local latest migration is `20260519_0004`, NOT `20260519_0002` as in the branch. Use `down_revision = "20260519_0004"`.

Create `D:\soul\backend\backend\alembic\versions\20260521_0001_add_webhook_events.py`:
```python
"""add webhook events

Revision ID: 20260521_0001
Revises: 20260519_0004
Create Date: 2026-05-21 12:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision = "20260521_0001"
down_revision = "20260519_0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create durable outbound webhook events."""

    op.create_table(
        "webhook_events",
        sa.Column("event_id", sa.String(length=128), nullable=False),
        sa.Column("event_type", sa.String(length=64), nullable=False),
        sa.Column("target_url", sa.String(length=1024), nullable=False),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("attempt_count", sa.Integer(), nullable=False),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("delivered_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("id", sa.BigInteger(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id", name=op.f("pk_webhook_events")),
    )
    op.create_index("ix_webhook_events_event_id", "webhook_events", ["event_id"], unique=True)
    op.create_index(
        "ix_webhook_events_status_next_attempt",
        "webhook_events",
        ["status", "next_attempt_at"],
        unique=False,
    )


def downgrade() -> None:
    """Drop durable outbound webhook events."""

    op.drop_index("ix_webhook_events_status_next_attempt", table_name="webhook_events")
    op.drop_index("ix_webhook_events_event_id", table_name="webhook_events")
    op.drop_table("webhook_events")
```

- [ ] **Step 2: Commit**

```bash
cd D:/soul/backend
git add backend/alembic/versions/20260521_0001_add_webhook_events.py
git commit -m "feat: add alembic migration for webhook_events table (backport feat/02-followup-webhook)"
```

---

## Task 7: feat/02-followup-webhook — Tests

**Files:**
- Create: `D:\soul\backend\backend\tests\test_followup_webhook.py`
- Modify: `D:\soul\backend\backend\tests\test_evaluation_tasks.py`

- [ ] **Step 1: Create `test_followup_webhook.py`**

Create `D:\soul\backend\backend\tests\test_followup_webhook.py` with the full content from the branch diff. The file is 341 lines — copy it exactly from `duoduo/feat/02-followup-webhook:backend/tests/test_followup_webhook.py`.

To get the content:
```bash
cd D:/soul/.claude/worktrees/friendly-dhawan
git show duoduo/feat/02-followup-webhook:backend/tests/test_followup_webhook.py > /tmp/test_followup_webhook.py
```
Then copy it to `D:\soul\backend\backend\tests\test_followup_webhook.py`.

- [ ] **Step 2: Append webhook test to `test_evaluation_tasks.py`**

Read the existing local `D:\soul\backend\backend\tests\test_evaluation_tasks.py` to find its end. Append the new test:

```python


async def test_evaluation_task_creates_followup_webhook_event_when_done(
    task_context: TaskContext,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("FOLLOWUP_WEBHOOK_URL", "https://crm.example.test/webhook")
    monkeypatch.setenv("FOLLOWUP_WEBHOOK_SECRET", "secret-key")
    get_settings.cache_clear()
    evaluation_id, user_id, _ = await create_task_fixture(task_context)

    result = await _run_evaluation_async(evaluation_id, user_id, "celery-task-id")

    assert result["status"] == "done"
    async with task_context.session_factory() as session:
        events = (await session.scalars(select(WebhookEvent))).all()
        assert len(events) == 1
        assert events[0].event_type == "evaluation.done"
        assert events[0].status == "pending"
        assert events[0].payload["status"] == "done"
```

Also add to the imports section at the top of `test_evaluation_tasks.py`:
```python
from app.core.config import get_settings
from app.db.models.webhook_event import WebhookEvent
```

And in the `task_context` fixture where tables are created, add:
```python
await connection.run_sync(WebhookEvent.__table__.create)
```

- [ ] **Step 3: Run the tests to verify**

```bash
cd D:/soul/backend/backend
python -m pytest tests/test_followup_webhook.py -v 2>&1 | head -60
```
Expected: all tests pass.

- [ ] **Step 4: Commit**

```bash
cd D:/soul/backend
git add backend/tests/test_followup_webhook.py backend/tests/test_evaluation_tasks.py
git commit -m "test: add followup webhook tests (backport feat/02-followup-webhook)"
```
