# 深度市场洞察文章（可折叠）设计

**日期：** 2026-05-22
**所属页面：** `miniprogram/pages/report/report`
**改动范围：** 报告页底部新增一块可折叠的文章体深度洞察区块；后端 `BusinessReport` 新增一个字段承载文章正文；不改动既有调研报告任何视图与字段。

---

## 1. 背景与动机

当前 `report` 页已呈现核心结论、机会点、风险点、人群与渠道、用户原声、下一步策略。这些是结构化的卡片视图，便于扫读，但难以表达"哪个卖点真正戳中哪类群体"、"哪个卖点在所有群体都失语"、"产品如何调整以适配真实市场"这类需要因果归因的深度判断。

用户希望以"分析体文章"的形式补充这类内容，提供决策者级别的可读性，但不能干扰既有卡片视图。

## 2. 目标与非目标

**目标**
- 在原有报告下方新增"展开深度市场洞察"折叠入口，默认收起。
- 展开后呈现一篇 AI 生成的、可阅读的分析体文章，结构对齐正式市场研究报告。
- 不改动原有报告的任何字段、视图、交互。
- 文章内容由后端在生成 `BusinessReport` 时一并生成，前端只负责渲染与折叠交互。

**非目标**
- 不重写已有的 PDF/白皮书导出链路（保留"查看完整报告 / 导出 PDF"按钮不动）。
- 不在 `BackendReport`（旧版 fallback）数据流中提供该内容；fallback 时该区块静默隐藏。
- 不引入图表、表格、列表符号；纯文字段落呈现。

## 3. 文章内容规范

**写作铁律（适用于后端 prompt 与前端兜底文案）**
- 全文不出现 "AI"、"虚拟"、"答题"、"受访者条数"、"置信度 X%" 等机制类词汇。
- 统一使用 "N 类受众群体"、"群体反映"、"群体声音"、"受众反应"。
- 行文为分析体：归因、因果、对比，不堆叠并列。
- 不出现口语助词（哦/呢/啦）、不出现营销感叹句。
- 段落以全角标点收口，单段不超过 5 行屏宽（约 100 汉字）以保证移动端可读性。

**结构骨架**

```
［产品名］卖点穿透力与市场适配深度洞察

摘要
本报告对［产品名］在 N 类受众群体中的反映样本进行深
度拆解，聚焦回答三个具有决策意义的问题：哪些卖点完
成了对特定人群的精准锚定、哪些卖点在所有群体面前丧
失了说服力、产品下一步应如何调整方能切入真实市场。

一、卖点穿透力的人群锁定
（开篇立论一段，说明本节归因逻辑）

（一）「卖点 A」——一句话定性副标题
  人群锁定：……
  共鸣触点：……
  边界提示：……

（二）「卖点 B」——一句话定性副标题
  …（同上结构）

二、转化无力的卖点诊断
（开篇立论一段）

（一）现象描述：……
（二）归因分析：……
（三）处置建议：……

三、市场适配的落地路径
（开篇立论一段）

（一）……：（一段分析+一条动作）
（二）……：（同上）
（三）……：（同上）
```

**节数与子节数约束**
- 一级章节固定三章：「卖点穿透力的人群锁定」「转化无力的卖点诊断」「市场适配的落地路径」。
- 第一章子节数 = `marketing_copy_angles.length`，上限取前 4 条。
- 第二章固定三子节（现象 / 归因 / 处置）。
- 第三章子节数 = `next_test_recommendations.length`，上限取前 4 条。

## 4. 数据契约

### 4.1 `BusinessReport` 新增字段

```ts
// miniprogram/types/api.ts
export interface DeepInsightArticle {
  title: string;          // 完整文章标题
  abstract: string;       // 摘要段（单段）
  sections: Array<{
    heading: string;      // 一级标题，含序号，如 "一、卖点穿透力的人群锁定"
    intro: string;        // 章节首段（立论段）
    subsections: Array<{
      heading: string;    // 二级标题，含序号，如 "（一）「天然成分无添加」——成分理性派的信任锚点"
      paragraphs: Array<{
        label: string;    // 标签，如 "人群锁定"；为空则纯段落
        body: string;     // 段落正文
      }>;
    }>;
  }>;
}

export interface BusinessReport {
  // ...既有字段保持不变
  deep_insight_article?: DeepInsightArticle | null;
}
```

字段为可选；旧数据缺该字段时前端静默隐藏入口。

### 4.2 后端生成方式（实施细节由后端落地，本文档仅约束输入输出）

- 在生成 `BusinessReport` 的同一 pipeline 中追加一次 LLM 调用。
- 输入：`marketing_copy_angles`、`top_pros`、`top_cons`、`target_audience`、`next_test_recommendations`、`metrics.persona_segments`、`product.name`。
- Prompt 中显式约束第 3 节"写作铁律"。
- 输出严格匹配 `DeepInsightArticle` JSON schema；后端解析失败则字段返回 `null`，前端隐藏入口。

## 5. 前端实现规范

### 5.1 触发入口

位置：`report.wxml` 中 `rp-disclaimer` 之上，`rp-actions` 之下。

外观（纯文字+下箭头 SVG）：

```
────────────────────────────────
深度市场洞察                    ∨
────────────────────────────────
```

- 触发区是一整行的 `<view bindtap>`，无按钮边框，仅上下细分隔线。
- 右侧箭头使用现有 SVG 资产或新增一个 chevron-down 图标；展开时 `transform: rotate(180deg)`。

### 5.2 折叠动画

- 状态 `insightOpen: boolean`，默认 `false`。
- 内容容器使用 `max-height` + `overflow: hidden` + `transition: max-height 0.35s ease`。
- 收起态 `max-height: 0`；展开态 `max-height: 8000rpx`（足够覆盖最长内容）。
- 不使用 `wx:if`，确保动画连续。

### 5.3 文章渲染

新增容器 `rp-insight-article`，内部按 `DeepInsightArticle` 嵌套渲染：

```
<view class="ria">
  <view class="ria-title">{{vm.article.title}}</view>

  <view class="ria-abstract-label">摘要</view>
  <view class="ria-abstract">{{vm.article.abstract}}</view>

  <block wx:for="{{vm.article.sections}}" wx:key="heading" wx:for-item="sec">
    <view class="ria-h1">{{sec.heading}}</view>
    <view class="ria-intro">{{sec.intro}}</view>
    <view class="ria-sub" wx:for="{{sec.subsections}}" wx:key="heading" wx:for-item="sub">
      <view class="ria-h2">{{sub.heading}}</view>
      <view class="ria-p" wx:for="{{sub.paragraphs}}" wx:key="label" wx:for-item="p">
        <text wx:if="{{p.label}}" class="ria-label">{{p.label}}：</text>{{p.body}}
      </view>
    </view>
  </block>
</view>
```

### 5.4 样式要点

- 标题字号阶梯：title 36rpx 加粗 → h1 30rpx 半粗 → h2 28rpx 半粗 → 正文 26rpx 常规。
- 行高 1.7，段间距 24rpx，整段两端不缩进、首行不缩进（与既有卡片正文一致）。
- `ria-label` 用半粗字重，与段落正文同字号，标签与正文之间无换行（行内连排）。
- 分隔线：摘要与第一章之间、章节之间用一条 1rpx `rgba(0,0,0,0.08)` 细线。
- 整体背景沿用现有页面纸感底色；不引入新的色块容器。

### 5.5 `buildVM` 改动

`buildVM(report, productName)` 新增：

```ts
article: report.deep_insight_article || null,
```

`buildBaseVM`（fallback）保持不返回该字段，使前端 `wx:if="{{vm.article}}"` 自然隐藏入口。

### 5.6 交互方法

`report.ts` 新增：

```ts
onTapToggleInsight() {
  this.setData({ insightOpen: !this.data.insightOpen });
}
```

## 6. 边界与降级

- 后端返回 `deep_insight_article = null` 或缺字段：入口不渲染。
- 文章存在但某章节空数组：跳过该节，不渲染空 heading。
- 文章超长导致 `max-height` 不足：将 `max-height` 提至 16000rpx；首次展开后改用 `auto`（通过设置 class 切换或在动画结束回调内解除约束，避免后续插入新段落时被裁切）。
- 文案中如果出现违禁词（"虚拟"/"AI"/"答题"/"受访者"）：后端 prompt 已约束；前端不做二次过滤，由后端保证。

## 7. 范围之外

- PDF/白皮书已有独立链路，不在本次改动内同步。
- 不为该区块加分享、复制、收藏入口（保持页面分享走顶层）。
- 不对既有报告卡片的字段、排序、文案做任何调整。

## 8. 验收

1. 旧 `BusinessReport` 数据（无新字段）打开报告页：底部不出现深度洞察入口；既有视图完全一致。
2. 新数据加载后，底部出现折叠入口；点击展开，箭头旋转、内容动画展开。
3. 文章按规范层级渲染；通读全文不出现违禁机制词。
4. fallback 至 `BackendReport`：入口不出现。
5. 重新进入页面，折叠状态恢复为默认收起。
